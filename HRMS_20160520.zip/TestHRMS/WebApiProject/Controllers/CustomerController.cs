﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using HRMSModels.Models;
using HRMSRepository;
using System.Web.Mvc;

namespace WebApiProject.Controllers
{
   
    public class CustomerController : ApiController
    {
        static readonly ICustomerRepository repository = new CustomerRepository();

        public IEnumerable<CustomerModel> GetAllCustomers(string active, string contactname, int LoggedUserId)
        {
            return repository.GetAll(active, contactname, LoggedUserId);
        }
        
        public bool GetCheckDuplicateCompanyName(string CompanyName, string CustomerId)
        {
            return repository.CheckDuplicateCompanyName(CompanyName, CustomerId);
        }

        public CustomerModel GetCustomer(string CustomerId)
        {
            CustomerModel cust = repository.Get(CustomerId);
            if (cust == null)
            {
                return null;
               // throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return cust;
        }

        //public CustomerModel PostProduct(CustomerModel cust)
        //{
        //    cust = repository.Add(cust);
        //    return cust;
        //}
     
        public bool PostCustomer(CustomerModel cust)
        {
            cust = repository.Add(cust);
            /*var resp = Request.CreateResponse<CustomerModel>(HttpStatusCode.Created, cust);

            string uri = Url.Link("DefaultApi", new { customerId = cust.CustomerId });
            resp.Headers.Location = new Uri(uri);

            return resp;
            //return NotFound();*/
            if (cust != null)
                return true;
            else
                return false;
        }

        public bool PutCustomer(CustomerModel cust)
        {
            /*cust.CustomerId = CustomerId;
            if (!repository.Update(cust))
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }*/
            return repository.Update(cust);
        }

        public void DeleteProduct(string CustomerId)
        {
            CustomerModel cust = repository.Get(CustomerId);
            if (cust == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            repository.Remove(CustomerId);
        }
    }
}
