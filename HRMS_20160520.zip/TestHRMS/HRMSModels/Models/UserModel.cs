﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Globalization;

namespace HRMSModels.Models
{
    public class UserModel
    {
        [Display(Name = "id")]
        public int id { get; set; }

        //[Remote("CheckUserName", "Account", ErrorMessage = "Duplicate User Name")]
        [Required(ErrorMessage = "User Name is required.")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "User name should be at least 5 characters long.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "Password should be at least 6 characters long.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "First Name is required.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "E-mail is not valid")]
        public string Email { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public int CityId { get; set; }

        public bool IsActive { get; set; }

        public bool IsAdmin { get; set; }

        public string ActiveStatus { get; set; }

        public DateTime Date { get; set; }
        public string DisplayedDate
        {
            get
            {
                return Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
        }

        public bool Deactive { get; set; }

        public int CreatedBy { get; set; }

        public int ModifiedBy { get; set; }

        public string EncryptId { get; set; }
    }
}
