﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;
using HRMSData;
using System.Web;

namespace HRMSRepository
{
    public class CustomerRepository: ICustomerRepository
    {
        HRMSEntities db = new HRMSEntities();
        static readonly IUserRepository usrRep = new UserRepository();

        public IEnumerable<CustomerModel> GetAll(string active, string contactname, int LoggedUserId)
        {
            List<CustomerModel> cust = new List<CustomerModel>();
            bool Deact = false;

            if (active == "0")
                Deact = false;
            else
                Deact = true;

            var query = (from c in db.Customers
                         join r in db.Cities on c.CityId equals r.id
                         where c.deactive == Deact
                         orderby c.CustomerId
                         select new CustomerModel { CustomerId = c.CustomerId, CompanyName = c.CompanyName, ContactName = c.ContactName, ContactTitle = c.ContactTitle, CityName = r.CityName, PhoneNumber = c.PhoneNumber, ActiveStatus = c.deactive == true ? "False" : "True", Date = (DateTime)c.CreatedOn, CreatedBy = (int)c.CreatedBy });

            if (contactname != "" && contactname != null)
                query = query.Where(u => u.ContactName.Contains(contactname));

            UserModel usr = usrRep.CheckLoggedUserIsAdmin(LoggedUserId);

            if (!usr.IsAdmin)
                query = query.Where(x => x.CreatedBy == LoggedUserId);

            cust = query.ToList();

            return cust;
        }

        public CustomerModel Get(string CustomerId)
        {
            return db.Customers.Where(c => c.CustomerId.ToString() == CustomerId).Select(u => new CustomerModel { CustomerId = u.CustomerId, CompanyName = u.CompanyName, ContactName = u.ContactName, ContactTitle = u.ContactTitle, CityId = (int)u.CityId, PhoneNumber = u.PhoneNumber, deactive = (bool)u.deactive, DealsIn = u.DealsIn }).ToList().FirstOrDefault();
        }

        public CustomerModel Add(CustomerModel item)
        {
            HRMSData.Customer cust = new HRMSData.Customer();
            cust.CompanyName = item.CompanyName;
            cust.ContactName = item.ContactName;
            cust.ContactTitle = item.ContactTitle;
            cust.CityId = item.CityId;
            cust.PhoneNumber = item.PhoneNumber;
            cust.CreatedBy = item.CreatedBy;
            cust.CreatedOn = DateTime.Now;
            cust.deactive = false;
            cust.DealsIn = item.DealsIn;

            db.Customers.Add(cust);
            db.SaveChanges();

            return db.Customers.Where(c => c.CustomerId == cust.CustomerId).Select(u => new CustomerModel { CustomerId = u.CustomerId, CompanyName = u.CompanyName, ContactName = u.ContactName, ContactTitle = u.ContactTitle, CityId = (int)u.CityId, PhoneNumber = u.PhoneNumber, deactive = (bool)u.deactive }).ToList().FirstOrDefault();
        }

        public void Remove(string CustomerId)
        {
            HRMSData.Customer cust = db.Customers.Where(c => c.CustomerId.ToString() == CustomerId).FirstOrDefault();

            db.Customers.Remove(cust);
            db.SaveChanges();
        }

        public bool Update(CustomerModel item)
        {
            bool UserEntry = false;

            HRMSData.Customer cust = db.Customers.Where(c => c.CustomerId == item.CustomerId).FirstOrDefault();
            cust.CompanyName = item.CompanyName;
            cust.ContactName = item.ContactName;
            cust.ContactTitle = item.ContactTitle;
            cust.CityId = item.CityId;
            cust.PhoneNumber = item.PhoneNumber;
            cust.ModifiedBy = item.ModifiedBy;
            cust.ModifiedOn = DateTime.Now;
            cust.deactive = item.deactive;
            cust.DealsIn = item.DealsIn;

            db.SaveChanges();

            UserEntry = true;

            return UserEntry;
        }

        public bool CheckDuplicateCompanyName(string CompanyName, string CustomerId)
        {
            bool RetValue = false;

            var query = (from c in db.Customers
                         where c.CompanyName == CompanyName && c.deactive == false && c.CustomerId.ToString() != CustomerId
                         select c);

            int count = query.Count();

            if (count > 0)
            {
                RetValue = true;
            }

            return RetValue;
        }
    }
}
