﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;
using HRMSData;

namespace HRMSRepository
{
    public class UserRepository: IUserRepository
    {
        HRMSEntities db = new HRMSEntities();

        public UserModel CheckUserLogin(string UserName, string Password)
        {
            return db.Users.Where(u => u.UserName == UserName && u.Password == Password).Select(x => new UserModel { id = x.id, IsActive = (bool)x.IsActive, Password = x.Password, Gender = x.Gender, FirstName = x.FirstName, LastName = x.LastName, IsAdmin = (bool)x.IsAdmin, Deactive = (bool)x.Deactive }).ToList().FirstOrDefault();
        }

        public UserModel CheckLoggedUserIsAdmin(int LoggedUserId)
        {
            return db.Users.Where(u => u.id == LoggedUserId).Select(x => new UserModel { IsAdmin = (bool)x.IsAdmin }).ToList().FirstOrDefault();
        }

        public bool CheckDuplicateUserName(string UserName)
        {
            return db.Users.Any(u => u.UserName == UserName);
        }

        public bool UserAddEdit(UserModel obj, string CallType)
        {
            bool UserEntry = false;

            if (CallType == "insert")
            {
                HRMSData.User usr = new HRMSData.User();
                usr.UserName = obj.UserName;
                usr.Password = obj.Password;
                usr.FirstName = obj.FirstName;
                usr.LastName = obj.LastName;
                usr.Email = obj.Email;
                usr.Gender = obj.Gender;
                usr.CityId = obj.CityId;
                usr.IsActive = true;
                usr.CreatedBy = obj.CreatedBy;
                usr.CreatedOn = DateTime.Now;
                usr.IsAdmin = false;
                usr.Deactive = false;

                db.Users.Add(usr);
                db.SaveChanges();

                UserEntry = true;
            }
            if (CallType == "update")
            {
                HRMSData.User usr = db.Users.Where(u => u.id == obj.id).FirstOrDefault();
                usr.Password = obj.Password;
                usr.FirstName = obj.FirstName;
                usr.LastName = obj.LastName;
                usr.Email = obj.Email;
                usr.Gender = obj.Gender;
                usr.CityId = obj.CityId;
                usr.ModifiedBy = obj.ModifiedBy;
                usr.ModifiedOn = DateTime.Now;
                usr.Deactive = obj.Deactive;

                db.SaveChanges();

                UserEntry = true;
            }
            if (CallType == "changepassword")
            {
                HRMSData.User usr = db.Users.Where(u => u.id == obj.id).FirstOrDefault();
                usr.Password = obj.Password;
                usr.ModifiedOn = DateTime.Now;
                usr.ModifiedBy = obj.ModifiedBy;

                db.SaveChanges();

                UserEntry = true;
            }

            return UserEntry;
        }

        public UserModel GetSingleUserOnId(string UserId)
        {
            return db.Users.Where(u => u.id.ToString() == UserId).Select(x => new UserModel { UserName = x.UserName, Password = x.Password, FirstName = x.FirstName, LastName = x.LastName, Email = x.Email, Gender = x.Gender, CityId = x.CityId == null ? 0 : (int)x.CityId, Deactive = (bool)x.Deactive, id = x.id }).ToList().FirstOrDefault();
        }

        public UserModel CheckValidOldPassword(string id, string password)
        {
            return db.Users.Where(u => u.id.ToString() == id && u.Password == password).Select(x => new UserModel { Password = x.Password }).ToList().FirstOrDefault();
        }

        public List<UserModel> GetSearchUser(string status, string FirstName, string LastName)
        {
            List<UserModel> obj = new List<UserModel>();
            bool Deactive = false;
            if (status == "0")
                Deactive = false;
            else
                Deactive = true;

            var query = db.Users.Where(u => u.Deactive == Deactive && u.IsAdmin == false).Select(x => new UserModel { id = x.id, Gender = x.Gender == "mr" ? "Mr." : x.Gender == "ms" ? "Ms." : "Others", FirstName = x.FirstName, LastName = x.LastName, Email = x.Email, Date = (DateTime)x.CreatedOn, ActiveStatus = x.Deactive == false ? "True" : "False", EncryptId = x.id.ToString() });

            if (FirstName != null && FirstName != "")
                query = query.Where(u => u.FirstName.Contains(FirstName));

            if (LastName != null && LastName != "")
                query = query.Where(u => u.LastName.Contains(LastName));

            obj = query.ToList();

            if (obj.Count > 0)
            {
                for (int iloop = 0; iloop < obj.Count; iloop++)
                {
                    obj[iloop].EncryptId = CommonClasses.GlobalFunctions.EncodeToBase64(obj[iloop].id.ToString());
                }
            }

            return obj;
        }
    }
}
