﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSModels.Models;

namespace HRMSRepository
{
    public interface ICustomerRepository
    {
        IEnumerable<CustomerModel> GetAll(string active, string contactname, int LoggedUserId);
        CustomerModel Get(string CustomerId);
        CustomerModel Add(CustomerModel item);
        void Remove(string CustomerId);
        bool Update(CustomerModel item);
        bool CheckDuplicateCompanyName(string CompanyName, string CustomerId);
    }
}
