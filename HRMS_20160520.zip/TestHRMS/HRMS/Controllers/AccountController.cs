﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.IO;
using HRMSRepository;
using HRMSModels.Models;
using System.ComponentModel.DataAnnotations;
using aspNetMX;
using System.Web.Security;
using AttributeRouting;
using AttributeRouting.Web.Mvc;


namespace HRMS.Controllers
{
   
    public class AccountController : Controller
    {
        //
        // GET: /Account/
        static readonly ICityRepository cities = new CityRepository();
        static readonly IUserRepository ur = new UserRepository();
        
        private static readonly ApiHandler api = new ApiHandler();

        /*[HttpGet]
        public CustomerViewModel Search()
        {
           
            string result = api.GetCall("Search", "Customers/Customer");
            customer = (CustomerViewModel)Newtonsoft.Json.JsonConvert.DeserializeObject(result, typeof(CustomerViewModel));
            if (customer != null)
            {
                return customer;
            }
            return null;
        }*/
      
        public ActionResult Index()
        {
            return View();
        }
        
        public ActionResult Login()
        {
            ViewBag.Title = "HRMS - User Login";
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginModel login)
        {
            ModelState.Clear();

            ViewBag.Title = "HRMS - User Login";

            if (login.UserName != null && login.UserName.Trim() != "")
            {
                UserModel usr = ur.CheckUserLogin(login.UserName, login.Password);
                bool Deactive = false;
                
                if (usr != null)
                {
                    if (usr.id != null)
                    {
                        if (IsNumeric(usr.id))
                        {
                            Deactive = usr.Deactive;
                            if (login.Password == usr.Password)
                            {
                                if (!Deactive)
                                {
                                    Session["UserId"] = usr.id;
                                    string UserId = usr.id.ToString();
                                    
                                    string gender = usr.Gender;
                                    
                                    if (gender == "mr")
                                        gender = "Mr. ";
                                    else if (gender == "ms")
                                        gender = "Ms. ";

                                    if (usr.IsAdmin)
                                        Session["UserName"] = gender + usr.FirstName + " " + usr.LastName + " (Admin)";
                                    else
                                        Session["UserName"] = gender + usr.FirstName + " " + usr.LastName;

                                    Session["IsAdmin"] = usr.IsAdmin;

                                    FormsAuthentication.SetAuthCookie(UserId, false);
                                    return RedirectToAction("Home");
                                }
                            }
                            //return RedirectToAction("Home");    
                        }
                    }
                }

                if (!Deactive)
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Invalid user name or password!";
                }
                else
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Sorry you do not have rights to access this site!";
                }
            }

            return View();
        }

        private static bool IsNumeric(object Expression)
        {
            double retNum;

            bool isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        public ActionResult Dummy()
        {
            return PartialView();
        }

        public ActionResult Home()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Home";

            return View();
        }

        private string RenderRazorViewToString(string viewName, object model)
        {
            ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
                var viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(ControllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }
    }
}
