﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AttributeRouting;
using AttributeRouting.Web.Mvc;
using HRMSRepository;
using HRMSModels.Models;

namespace HRMS.Controllers
{
	[RoutePrefix("User")]
    public class UserController : Controller
    {
        static readonly ICityRepository cities = new CityRepository();
        static readonly IUserRepository ur = new UserRepository();
        
        /*[HttpGet]
        public ActionResult AddUser()
        {
            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";
            return View();
        }*/

        [HttpGet]
        public ActionResult UserProfile()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - User Profile";

            return View(ur.GetSingleUserOnId(Session["UserId"].ToString()));
        }

        [HttpPost]
        [Route("Profile")]
        public ActionResult UserProfile(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            ViewBag.Title = "HRMS - User Profile";

            usr.id = (int)Session["UserId"];
            usr.ModifiedBy = (int)Session["UserId"];

            if (ur.UserAddEdit(usr, "update"))
            {
                TempData["Message"] = "User updated successfully.";
                TempData["ErrorMessage"] = "";
            }
            else
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "System error. Please try again!";
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            return View(ur.GetSingleUserOnId(Session["UserId"].ToString()));
        }

        /*[HttpPost]
        public ActionResult AddUser(UserModel usr)
        {
            ModelState.Clear();

            if (usr.UserName != null && usr.UserName.Trim() != "")
            {
                if (ur.UserAddEdit(usr, "insert"))
                {
                    TempData["Message"] = "User added successfully.";
                    TempData["ErrorMessage"] = "";

                    return RedirectToAction("Login");
                }
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";

            TempData["Message"] = "";
            TempData["ErrorMessage"] = "System error. Please try again!";

            return View();
        }*/

        public ActionResult CheckUserName(string UserName)
        {
            bool RetValue = ur.CheckDuplicateUserName(UserName);

            return Json(!RetValue, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ChangePassword()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ViewBag.Title = "HRMS - Change Password";
            return View();
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel obj)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            if (obj.NewPassword == obj.OldPassword)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Old and New Password cannot be same!";
            }
            else if (obj.NewPassword != obj.ConfirmNewPassword)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "New and Confirm password must be same!";
            }
            else if (obj.NewPassword.Length < 6)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "New password should be at least 6 characters long!";
            }
            else
            {
                UserModel usr = ur.CheckValidOldPassword(Convert.ToString(Session["UserId"]), obj.OldPassword);
                bool ValidUser = false;

                if (usr != null)
                {
                    if (obj.OldPassword == usr.Password)
                    {
                        ValidUser = true;
                    }
                }

                if (ValidUser)
                {
                    usr.id = Convert.ToInt32(Session["UserId"]);
                    usr.Password = obj.NewPassword;
                    usr.ModifiedBy = Convert.ToInt32(Session["UserId"]);

                    if (ur.UserAddEdit(usr, "changepassword"))
                    {
                        TempData["Message"] = "Password changed successfully!";
                        TempData["ErrorMessage"] = "";
                    }
                    else
                    {
                        TempData["Message"] = "";
                        TempData["ErrorMessage"] = "System error. Please try again!";
                    }
                }
                else
                {
                    TempData["Message"] = "";
                    TempData["ErrorMessage"] = "Invalid old password!";
                }
            }

            ViewBag.Title = "HRMS - Change Password";
            return View();
        }

        [HttpGet]
        [Route("UserList")]
        public ActionResult GetAllUsers(string ActiveStatus, string FirstName, string LastName)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            bool SearchCriteria = false;

            if (ActiveStatus == null)
                ActiveStatus = "0";
            else
                SearchCriteria = true;

            ViewBag.Title = "HRMS - User List";

            if (SearchCriteria)
                return PartialView("_userlist", ur.GetSearchUser(ActiveStatus, FirstName, LastName));
            else
                return View(ur.GetSearchUser(ActiveStatus, FirstName, LastName));
        }

        [HttpGet]
        [Route("AddUser")]
        public ActionResult AddNewUser()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";
            return View();
        }

        [HttpPost]
        public ActionResult AddNewUser(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            if (usr.UserName != null && usr.UserName.Trim() != "")
            {
                usr.CreatedBy = Convert.ToInt32(Session["UserId"]);
                if (ur.UserAddEdit(usr, "insert"))
                {
                    return RedirectToAction("GetAllUsers");
                }
            }

            //bool blnValue = IsValidEmail(usr.Email);

            ViewBag.Message = "";
            ViewBag.ErrorMessage = "System error. Please try again!";

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - New User";

            return View();
        }

        /*private bool IsValidEmail(string EmailId)
        {
            /*string key = "QER5N-C9DCL-5B3VP-EQR9M-YPR41-AEYA4-4QY5L-3721C-VGKRC-RU7XS-XK6JY-6JT5Y-DKY3";
            MXValidate.LoadLicenseKey(key);
            MXValidate mx = new MXValidate();

            mx.LogInMemory = true;

            mx.SMTPFrom = "sanjeevarora30@gmail.com";
            mx.SMTPHello = "mail.google.com";
            MXValidateLevel level = mx.Validate(EmailId, aspNetMX.MXValidateLevel.Mailbox);

            if (level == aspNetMX.MXValidateLevel.Mailbox)
                return true;
            else
                return false;
        }*/

        [HttpGet]
        [Route("EditUser")]
        public ActionResult EditUser(string UserID)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            if (string.IsNullOrEmpty(UserID))
                return RedirectToAction("GetAllUsers");

            UserID = HRMSRepository.CommonClasses.GlobalFunctions.DecodeFrom64(UserID);

            if (UserID == null)
                return RedirectToAction("GetAllUsers");

            ModelState.Clear();

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - Edit User";

            UserModel usr = ur.GetSingleUserOnId(UserID.ToString());

            if (usr == null)
                return RedirectToAction("GetAllUsers");
            else
                return View(usr);
        }

        [HttpPost]
        public ActionResult EditUser(UserModel usr)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            ViewBag.Title = "HRMS - Edit User";

            usr.ModifiedBy = (int)Session["UserId"];

            //bool blnValue = IsValidEmail(usr.Email);

            if (ur.UserAddEdit(usr, "update"))
            {
                /*TempData["Message"] = "User updated successfully.";
                TempData["ErrorMessage"] = "";*/

                return RedirectToAction("GetAllUsers");
            }
            TempData["Message"] = "";
            TempData["ErrorMessage"] = "System error. Please try again!";

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            return View(ur.GetSingleUserOnId(Convert.ToString(usr.id)));
        }
    }
}
