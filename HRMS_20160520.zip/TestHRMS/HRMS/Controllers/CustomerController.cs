﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HRMSModels.Models;
using HRMSRepository;
using System.Web.Script.Serialization;
using AttributeRouting;
using AttributeRouting.Web.Mvc;

namespace HRMS.Controllers
{
    [RoutePrefix("Customer")]
    public class CustomerController : Controller
    {
        //
        // GET: /Customer/
        private static readonly ApiHandler api = new ApiHandler();
        static readonly ICityRepository cities = new CityRepository();
        
        public ActionResult Index()
        {
            return View();
        }

        [Route("CustomerList")]
        public ActionResult GetAllCustomer(string ActiveStatus, string ContactName)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            bool SearchCriteria = false;

            if (ActiveStatus == null)
                ActiveStatus = "0";
            else
                SearchCriteria = true;

            if (ContactName == null)
                ContactName = "";

            string result = api.GetCall("GetAllCustomers", "Customer", ActiveStatus, ContactName, Convert.ToInt32(Session["UserId"]));
            List<CustomerModel> cust = (List<CustomerModel>)Newtonsoft.Json.JsonConvert.DeserializeObject(result, typeof(List<CustomerModel>));
            ViewBag.Title = "HRMS - Customer List";

            if (cust != null)
            {
                if (SearchCriteria)
                    return PartialView("_customerlist", cust);
                else
                    return View(cust);
            }

            return null;
        }

        [HttpGet]
        [Route("AddCustomer")]
        public ActionResult AddCustomer()
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();
            ViewBag.Title = "HRMS - Add Customer";
            return View();
        }

        [HttpPost]
        public ActionResult AddCustomer(CustomerModel cust)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            ViewBag.Title = "HRMS - Add Customer";

            var DuplicateCompany = api.GetDuplicateCompany("GetCheckDuplicateCompanyName", "Customer", cust.CompanyName, "0");

            if (DuplicateCompany == "true")
            {
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();
                
                ViewBag.Message = "";
                ViewBag.ErrorMessage = "Company name already exists!";
            }
            else
            {
                cust.CreatedBy = Convert.ToInt32(Session["UserId"]);

                var jsonData = new JavaScriptSerializer().Serialize(cust);
                string path = "api/Customer/PostCustomer";

                var Result = api.PostCall(path, jsonData);

                if (Result == "true")
                {
                    return RedirectToAction("GetAllCustomer");
                }
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();
                
                ViewBag.Message = "";
                ViewBag.ErrorMessage = "System error. Please try again!";
            }

            return View(cust);
        }

        [HttpGet]
        [Route("EditCustomer")]
        public ActionResult EditCustomer(string id)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            if (string.IsNullOrEmpty(id))
                return RedirectToAction("GetAllCustomer");

            ModelState.Clear();

            var city = new SelectList(cities.GetAllCities(), "id", "CityName");
            ViewBag.CitiesList = city.ToList();

            string result = api.GetCustomer("GetCustomer", "Customer", id);
            CustomerModel cust = (CustomerModel)Newtonsoft.Json.JsonConvert.DeserializeObject(result, typeof(CustomerModel));
            ViewBag.Title = "HRMS - Edit Customer";

            if (cust == null)
                return RedirectToAction("GetAllCustomer");
            else
                return View(cust);
        }

        [HttpPost]
        public ActionResult EditCustomer(CustomerModel cust)
        {
            if (Session["UserId"] == null)
            {
                TempData["Message"] = "";
                TempData["ErrorMessage"] = "Session out!";

                return RedirectToAction("Login", "Account");
            }

            ModelState.Clear();

            var DuplicateCompany = api.GetDuplicateCompany("GetCheckDuplicateCompanyName", "Customer", cust.CompanyName, cust.CustomerId.ToString());

            if (DuplicateCompany == "true")
            {
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();
                ViewBag.Title = "HRMS - Edit Customer";

                ViewBag.Message = "";
                ViewBag.ErrorMessage = "Company name already exists!";
            }
            else
            {
                cust.ModifiedBy = Convert.ToInt32(Session["UserId"]);

                var jsonData = new JavaScriptSerializer().Serialize(cust);
                string path = "api/Customer/PutCustomer";

                var Result = api.PutCall(path, jsonData);

                if (Result == "true")
                {
                    return RedirectToAction("GetAllCustomer");
                }
                var city = new SelectList(cities.GetAllCities(), "id", "CityName");
                ViewBag.CitiesList = city.ToList();
                ViewBag.Title = "HRMS - Edit Customer";

                ViewBag.Message = "done successfully";
                ViewBag.ErrorMessage = "";
            }

            return View(cust);
        }
    }
}
